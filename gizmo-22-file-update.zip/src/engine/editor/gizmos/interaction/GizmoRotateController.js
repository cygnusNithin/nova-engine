import * as THREE from "three";

import EditorTransform from "../../transform/EditorTransform";

import GizmoState from "../GizmoState";

class GizmoRotateController {
  constructor() {
    this.entity = null;

    this.axis = null;

    this.rotating = false;

    this.startRotation = new THREE.Euler();

    this.startVector = new THREE.Vector3();

    this.currentVector = new THREE.Vector3();

    this.rotationPlane = new THREE.Plane();

    this.rotationCenter = new THREE.Vector3();

    this.pointerId = null;

    this.pointerTarget = null;

    this.initialized = false;
  }

  // ============================================================
  // RESET
  // ============================================================

  reset() {
    this.entity = null;

    this.axis = null;

    this.rotating = false;

    this.startRotation.set(0, 0, 0);

    this.startVector.set(0, 0, 0);

    this.currentVector.set(0, 0, 0);

    this.rotationPlane.set(new THREE.Vector3(0, 1, 0), 0);

    this.rotationCenter.set(0, 0, 0);

    this.pointerId = null;

    this.pointerTarget = null;

    this.initialized = false;

    GizmoState.transforming = false;
    GizmoState.axis = null;
    GizmoState.hoveredAxis = null;
  }

  // ============================================================
  // BEGIN
  // ============================================================

  begin(
    entity,
    axis,
    startPoint,
    center,
    rotationPlane,
    pointerId = null,
    pointerTarget = null,
  ) {
    if (!entity) {
      return false;
    }

    if (!entity.transform) {
      return false;
    }

    if (!startPoint || !center || !rotationPlane) {
      return false;
    }

    if (axis !== "x" && axis !== "y" && axis !== "z") {
      return false;
    }

    if (this.rotating || GizmoState.transforming) {
      return false;
    }

    this.entity = entity;

    this.axis = axis;

    this.rotating = true;

    this.rotationCenter.copy(center);

    this.rotationPlane.copy(rotationPlane);

    this.startRotation.copy(entity.transform.rotation);

    this.startVector.copy(startPoint).sub(center).normalize();

    this.currentVector.copy(this.startVector);

    this.pointerId = pointerId;

    this.pointerTarget = pointerTarget;

    this.initialized = true;

    GizmoState.transforming = true;
    GizmoState.axis = axis;

    return true;
  }

  // ============================================================
  // UPDATE
  // ============================================================

  update(entity, axis, currentPoint, pointerId = null) {
    if (!this.rotating) {
      return false;
    }

    if (!this.initialized) {
      return false;
    }

    if (!entity || entity !== this.entity) {
      return false;
    }

    if (axis !== this.axis) {
      return false;
    }

    if (
      this.pointerId !== null &&
      pointerId !== null &&
      this.pointerId !== pointerId
    ) {
      return false;
    }

    if (!currentPoint) {
      return false;
    }

    this.currentVector.copy(currentPoint).sub(this.rotationCenter).normalize();

    if (
      this.startVector.lengthSq() < 1e-8 ||
      this.currentVector.lengthSq() < 1e-8
    ) {
      return false;
    }

    const axisVector = this.getAxisVector(axis);

    if (!axisVector) {
      return false;
    }

    const angle = this.getSignedAngle(
      this.startVector,
      this.currentVector,
      axisVector,
    );

    if (!Number.isFinite(angle)) {
      return false;
    }

    const rotation = this.startRotation.clone();

    switch (axis) {
      case "x":
        rotation.x = this.startRotation.x + angle;
        break;

      case "y":
        rotation.y = this.startRotation.y + angle;
        break;

      case "z":
        rotation.z = this.startRotation.z + angle;
        break;

      default:
        return false;
    }

    EditorTransform.setEntityRotation(
      entity,
      rotation.x,
      rotation.y,
      rotation.z,
    );

    return true;
  }

  // ============================================================
  // AXIS
  // ============================================================

  getAxisVector(axis) {
    switch (axis) {
      case "x":
        return new THREE.Vector3(1, 0, 0);

      case "y":
        return new THREE.Vector3(0, 1, 0);

      case "z":
        return new THREE.Vector3(0, 0, 1);

      default:
        return null;
    }
  }

  // ============================================================
  // SIGNED ANGLE
  // ============================================================

  getSignedAngle(from, to, axis) {
    const cross = new THREE.Vector3().crossVectors(from, to);

    const dot = THREE.MathUtils.clamp(from.dot(to), -1, 1);

    /*
     * atan2 gives us the full signed angle.
     *
     * This is better than:
     *
     * acos(dot) + Math.sign(...)
     *
     * because atan2 handles the sign and the 180-degree
     * boundary much more reliably.
     */
    return Math.atan2(cross.dot(axis), dot);
  }

  // ============================================================
  // END / COMMIT
  // ============================================================

  end(pointerId = null) {
    if (!this.rotating) {
      return false;
    }

    if (
      this.pointerId !== null &&
      pointerId !== null &&
      this.pointerId !== pointerId
    ) {
      return false;
    }

    this.releasePointerCapture();

    this.reset();

    return true;
  }

  // ============================================================
  // CANCEL
  // ============================================================

  cancel(pointerId = null) {
    if (!this.rotating) {
      return false;
    }

    if (
      this.pointerId !== null &&
      pointerId !== null &&
      this.pointerId !== pointerId
    ) {
      return false;
    }

    this.releasePointerCapture();

    if (this.entity?.transform) {
      EditorTransform.setEntityRotation(
        this.entity,
        this.startRotation.x,
        this.startRotation.y,
        this.startRotation.z,
      );
    }

    this.reset();

    return true;
  }

  // ============================================================
  // POINTER CAPTURE
  // ============================================================

  releasePointerCapture() {
    if (!this.pointerTarget || this.pointerId === null) {
      return;
    }

    try {
      if (
        typeof this.pointerTarget.hasPointerCapture === "function" &&
        this.pointerTarget.hasPointerCapture(this.pointerId)
      ) {
        this.pointerTarget.releasePointerCapture(this.pointerId);
      }
    } catch {
      // Pointer may already be released.
    }
  }

  // ============================================================
  // STATE
  // ============================================================

  isRotating() {
    return this.rotating;
  }

  getAxis() {
    return this.axis;
  }

  getEntity() {
    return this.entity;
  }

  getRotationCenter() {
    return this.rotationCenter.clone();
  }

  getRotationPlane() {
    return this.rotationPlane;
  }

  getPointerId() {
    return this.pointerId;
  }
}

export default new GizmoRotateController();
